from flask import Flask, request, jsonify
from flask_cors import CORS
import openai
import os
from PIL import Image
import pytesseract
from werkzeug.utils import secure_filename

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

openai.api_key = os.environ.get("OPENAI_API_KEY")

SYSTEM_PROMPT = """
You are AYON (Always Your Online Nerd), a humble and helpful AI tutor who explains everything clearly.
You help students 24/7 by:
- Writing essays and letters
- Explaining chapters in detail (like stories if it's history)
- Giving grammar practice and test papers
- Solving maths/science/computer questions in easy steps
- Explaining each civics term clearly
- Explaining geography topics and giving proper notes
"""

@app.route("/ask", methods=["POST"])
def ask_ayon():
    data = request.get_json()
    question = data.get("question")
    subject = data.get("subject")

    if not question:
        return jsonify({"error": "No question provided"}), 400

    prompt = f"Subject: {subject}\nQuestion: {question}"

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt}
            ]
        )
        return jsonify({"answer": response.choices[0].message.content.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/ocr", methods=["POST"])
def extract_text_from_image():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    image = request.files["image"]
    filename = secure_filename(image.filename)
    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    image.save(path)

    try:
        text = pytesseract.image_to_string(Image.open(path))
        return jsonify({"text": text.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)